# Быстрый старт - Logistics App

## 📦 Что находится в архиве

Полное Android приложение на Kotlin с использованием Jetpack Compose для управления транспортно-логистической компанией.

## 🚀 Быстрый запуск

### Шаг 1: Распаковка
```bash
unzip LogisticsApp.zip
cd LogisticsApp
```

### Шаг 2: Открытие в Android Studio
1. Запустите Android Studio
2. File → Open → выберите папку LogisticsApp
3. Дождитесь синхронизации Gradle (может занять несколько минут)

### Шаг 3: Запуск
1. Создайте AVD (Android Virtual Device) или подключите реальное устройство
2. Нажмите Run ▶️ (Shift+F10)
3. Приложение установится и запустится

## 📱 Основные возможности

✅ Управление заказами (просмотр, создание, редактирование)
✅ Дашборд со статистикой
✅ Отслеживание грузов по трек-номеру
✅ Фильтрация заказов по статусам
✅ Детальная информация о каждом заказе
✅ Современный Material 3 дизайн
✅ Адаптивный UI на Jetpack Compose

## 📚 Документация

- **README.md** - Полное описание проекта
- **USER_GUIDE.md** - Руководство пользователя
- **API_DOCUMENTATION.md** - Документация API для backend
- **ARCHITECTURE.md** - Архитектура приложения

## 🏗️ Структура проекта

```
LogisticsApp/
├── app/src/main/java/com/logistics/app/
│   ├── data/                    # Модели и репозитории
│   │   ├── model/              # Модели данных
│   │   └── repository/         # Логика работы с данными
│   ├── ui/                     # UI компоненты
│   │   ├── dashboard/          # Главный экран
│   │   ├── orders/             # Экраны заказов
│   │   ├── tracking/           # Отслеживание
│   │   └── theme/              # Тема приложения
│   └── MainActivity.kt         # Точка входа
├── app/src/main/res/           # Ресурсы
└── build.gradle.kts            # Зависимости
```

## 🎨 Технологии

- **Язык**: Kotlin
- **UI**: Jetpack Compose + Material 3
- **Архитектура**: MVVM
- **Навигация**: Navigation Compose
- **Async**: Kotlin Coroutines + Flow
- **Min SDK**: 24 (Android 7.0)
- **Target SDK**: 34 (Android 14)

## 📊 Демо данные

Приложение содержит тестовые данные для демонстрации:
- 4 заказа с разными статусами
- Клиенты, адреса, цены
- Трек-номера для отслеживания (например: TRK2025001)

## 🔧 Кастомизация

### Изменение цветов
Отредактируйте: `app/src/main/res/values/colors.xml`

### Изменение строк
Отредактируйте: `app/src/main/res/values/strings.xml`

### Подключение к API
Отредактируйте: `app/src/main/java/com/logistics/app/data/repository/OrderRepository.kt`

## 📝 TODO для production

- [ ] Подключить реальный backend API
- [ ] Добавить Room Database для офлайн режима
- [ ] Реализовать систему авторизации
- [ ] Добавить Firebase для push-уведомлений
- [ ] Интегрировать Google Maps для карт
- [ ] Добавить Hilt для Dependency Injection
- [ ] Написать тесты (Unit + UI)

## 💡 Советы

1. **Gradle sync не работает?** 
   - File → Invalidate Caches → Invalidate and Restart

2. **Ошибки компиляции?**
   - Проверьте версию Android Studio (рекомендуется последняя)
   - Build → Clean Project → Rebuild Project

3. **Медленная работа эмулятора?**
   - Используйте AVD с аппаратным ускорением (x86_64)
   - Выделите больше RAM в настройках AVD

## 🤝 Поддержка

При возникновении вопросов обращайтесь:
- Email: support@logistics-app.com
- Документация: см. файлы в проекте

## 📄 Лицензия

Проект разработан для образовательных целей.
Общая тема с Якушевым И.С.

---

**Приятной разработки! 🚀**
