using System.Windows.Controls;

namespace Djabarov_Mekhty_4ISIP_422.Pages
{
    public partial class AdminPage : Page
    {
        public AdminPage()
        {
            InitializeComponent();
        }
    }
}
