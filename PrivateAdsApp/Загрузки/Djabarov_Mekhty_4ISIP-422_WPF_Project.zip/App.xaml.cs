using System.Windows;

namespace Djabarov_Mekhty_4ISIP_422
{
    public partial class App : Application
    {
    }
}
