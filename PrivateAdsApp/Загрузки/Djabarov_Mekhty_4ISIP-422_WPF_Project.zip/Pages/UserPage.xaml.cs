using System.Windows.Controls;

namespace Djabarov_Mekhty_4ISIP_422.Pages
{
    public partial class UserPage : Page
    {
        public UserPage()
        {
            InitializeComponent();
        }
    }
}
